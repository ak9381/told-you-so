import { useState, useEffect, useRef } from 'react';
import {
  Search, Bell, Video, Mic, Link2, Upload, Clock, Check, X, Edit3,
  Play, MoreHorizontal, ChevronRight, ExternalLink, FileText,
  MessageSquare, Inbox, Zap, ShieldAlert, AlertTriangle, Database,
  Mail, Calendar, Grip, ArrowUpRight, Pause, Sparkles
} from 'lucide-react';

type ProjectId = 'client' | 'fintech' | 'judge';
type DayView = 'Day' | 'Week' | 'Month' | 'Year';
type CaptureTab = 'capture' | 'confirm' | 'act' | 'trace' | 'timeline';

interface ConfirmItem {
  id: string;
  kind: 'decision' | 'action' | 'objection_red' | 'conflict_yellow';
  quote: string;
  source: string;
  owner?: string;
  due?: string;
  status: 'pending' | 'accepted' | 'dropped';
  oldDecision?: string;
  oldSource?: string;
  newSource?: string;
  resolution?: string;
}

const PROJECTS = [
  { id: 'client' as ProjectId, name: 'Client Website #3', meta: '12 decisions • 3 open', dot: 'bg-zinc-900' },
  { id: 'fintech' as ProjectId, name: 'Fintech Demo', meta: '8 decisions • 1 conflict', dot: 'bg-zinc-400' },
  { id: 'judge' as ProjectId, name: 'Judge Demo Project', meta: '3 pending • READY', dot: 'bg-[#DC2626]', badge: 'READY' },
];

const INITIAL_CONFIRM: ConfirmItem[] = [
  {
    id: 'd1',
    kind: 'decision',
    quote: "Let's go with blue for landing — feels more trustworthy for fintech.",
    source: "Oct 29 · Demo Meeting · 03:14 · Riya Patel",
    status: 'pending',
  },
  {
    id: 'a1',
    kind: 'action',
    quote: "Ship API docs + sandbox keys before demo. Riya to send loom.",
    source: "Oct 29 · Demo Meeting · 03:42 · Extracted",
    owner: "@Riya",
    due: "Oct 31",
    status: 'pending',
  },
  {
    id: 'r1',
    kind: 'objection_red',
    quote: "Told you so: on Oct 24 you decided blue → now green?",
    source: "Conflict between Oct 24 and Oct 29",
    oldDecision: "We decided blue for landing — brand trust. (Oct 24, Meeting #12, 10:32 AM)",
    oldSource: "Oct 24 Meeting #12",
    newSource: "Oct 29 Demo Meeting — “let’s actually try green for landing, pop more”",
    status: 'pending',
  },
  {
    id: 'y1',
    kind: 'conflict_yellow',
    quote: "Sources don't match — WhatsApp says blue, Meeting says green",
    source: "WhatsApp export (yesterday 9:14pm) vs Meeting transcript",
    status: 'pending',
  },
];

export default function App() {
  const [activeProject, setActiveProject] = useState<ProjectId>('judge');
  const [activeTab, setActiveTab] = useState<CaptureTab>('capture');
  const [dayView, setDayView] = useState<DayView>('Week');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [modalCard, setModalCard] = useState<null | 'dictate' | 'live' | 'import' | 'wispr' | 'demo'>(null);
  const [isHoldingFn, setIsHoldingFn] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [importTab, setImportTab] = useState<'meet' | 'chat'>('meet');
  const [autoImport, setAutoImport] = useState(true);
  const [confirmItems, setConfirmItems] = useState<ConfirmItem[]>(INITIAL_CONFIRM);
  const [search, setSearch] = useState('');
  const [showBell, setShowBell] = useState(false);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{saved: number, remaining: number, error: string | null, reloadError: string | null} | null>(null);
  const [records, setRecords] = useState<any[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editQuote, setEditQuote] = useState('');
  const [tick, setTick] = useState(0);

  const mainRef = useRef<HTMLDivElement>(null);

  // ---- persistence ----
  const reloadRecords = async () => {
    try {
      const res = await fetch("actions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "records.list", args: { collection: "decisions" } })
      });
      const j = await res.json();
      if (j.error) throw new Error(j.error);
      setRecords(j.data?.records || []);
    } catch (e) {
      // silent fallback for preview without backend
      console.log('reload fallback', e);
    }
  };

  const createRow = async (row: any) => {
    const res = await fetch("actions", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "records.create", args: { collection: "decisions", value: row, idempotency_key: row._key || row.id } })
    });
    const j = await res.json();
    if (j.error) throw new Error(j.error);
    if (!res.ok) throw new Error('Failed to save');
    return j.data;
  };

  useEffect(() => {
    reloadRecords();
  }, []);

  const handleAcceptItem = async (item: ConfirmItem) => {
    setBusy(true);
    let saved = 0;
    let error: string | null = null;
    const rows = [{ ...item, status: 'accepted', _key: `${item.id}-${Date.now()}`, saved_at: new Date().toISOString() }];
    try {
      for (const row of rows) {
        await createRow(row);
        saved += 1;
      }
    } catch (e) {
      error = e instanceof Error ? e.message : String(e);
    }
    let reloadError: string | null = null;
    try {
      await reloadRecords();
    } catch (e) {
      reloadError = e instanceof Error ? e.message : String(e);
    }
    setResult({ saved, remaining: rows.length - saved, error, reloadError });
    setBusy(false);
    setConfirmItems(prev => prev.map(p => p.id === item.id ? { ...p, status: 'accepted' } : p));
  };

  const handleAcceptAll = async () => {
    const pending = confirmItems.filter(i => i.status === 'pending');
    setBusy(true);
    let saved = 0;
    let error: string | null = null;
    try {
      for (const row of pending) {
        const payload = { ...row, status: 'accepted', _key: `${row.id}-${Date.now()}-${saved}`, quote: row.quote.slice(0, 400), source: row.source };
        await createRow(payload);
        saved += 1;
      }
    } catch (e) {
      error = e instanceof Error ? e.message : String(e);
    }
    let reloadError: string | null = null;
    try {
      await reloadRecords();
    } catch (e) {
      reloadError = e instanceof Error ? e.message : String(e);
    }
    setResult({ saved, remaining: pending.length - saved, error, reloadError });
    setBusy(false);
    if (!error) setConfirmItems(prev => prev.map(p => ({ ...p, status: 'accepted' as const })));
  };

  // derived
  const pendingCount = confirmItems.filter(i => i.status === 'pending').length;
  const activeProjectMeta = PROJECTS.find(p => p.id === activeProject)!;

  return (
    <div
      data-safe-area-inset-root
      style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)' } as any}
      className="min-h-screen bg-[#FFFEF9] text-[#111827] selection:bg-black selection:text-white overflow-x-clip"
    >
      {/* soft gradient backdrop */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#FFFEF9] via-[#FFF8E8] to-[#FFF1E6]" />
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] rounded-full bg-[#FFEEDB]/60 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-5%] w-[50%] h-[50%] rounded-full bg-[#E8F0FF]/70 blur-[120px]" />
      </div>

      <div className="mx-auto max-w-[1600px] p-4 md:p-8 flex gap-6 md:gap-8 min-h-[calc(100vh-var(--safe-area-inset-top))]">

        {/* LEFT SIDEBAR */}
        <aside className={`
          hidden md:flex w-[280px] shrink-0 glass rounded-[28px] flex-col p-5
          sticky top-[calc(var(--safe-area-inset-top)+20px)] h-[calc(100vh-var(--safe-area-inset-top)-40px)] 
          overflow-hidden
        `}>
          <div className="flex items-center gap-3 mb-8">
            <div className="w-9 h-9 rounded-[12px] bg-black text-white flex items-center justify-center font-bold text-[13px] tracking-tighter">TYS</div>
            <div>
              <div className="display font-bold text-[18px] leading-none tracking-tight">TOLD YOU SO</div>
              <div className="mono text-[10px] tracking-[0.18em] text-zinc-500 mt-[2px]">DECISION MEMORY</div>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <div className="mono text-[11px] tracking-widest text-zinc-400 mb-3 flex items-center justify-between">
                PROJECTS
                <span className="w-5 h-5 rounded-full border border-zinc-200 flex items-center justify-center text-[10px]">3</span>
              </div>
              <div className="space-y-1.5">
                {PROJECTS.map(p => {
                  const active = activeProject === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => {
                        setActiveProject(p.id);
                        if (p.id === 'judge') setActiveTab('capture');
                        else setActiveTab('timeline');
                      }}
                      className={`w-full text-left group flex items-center gap-3 px-4 py-[13px] rounded-full transition-all duration-300 ${
                        active ? 'bg-black text-white shadow-[0_4px_16px_rgba(0,0,0,0.18)]' : 'hover:bg-white/80 text-zinc-700 hover:shadow-sm border border-transparent hover:border-zinc-200/60'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${active ? 'bg-white' : p.dot} shrink-0`} />
                      <div className="min-w-0 flex-1">
                        <div className={`text-[13.5px] font-medium leading-none truncate ${active ? 'text-white' : 'text-zinc-800'}`}>{p.name}</div>
                        <div className={`mono text-[11px] mt-1 truncate ${active ? 'text-zinc-300' : 'text-zinc-500'}`}>{p.meta}</div>
                      </div>
                      {p.badge && (
                        <span className={`mono text-[9px] px-2 py-1 rounded-full font-bold tracking-widest ${active ? 'bg-white text-black' : 'bg-[#DC2626] text-white'}`}>{p.badge}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-2">
              <div className="mono text-[11px] tracking-widest text-zinc-400 mb-3">CAPTURE</div>
              <div className="space-y-1">
                {[
                  { k: 'capture', label: 'Dictate + Import', icon: Mic },
                  { k: 'confirm', label: `Confirm Tray`, count: pendingCount, icon: Inbox },
                  { k: 'act', label: 'Act · Notion + Outbox', icon: Zap },
                  { k: 'trace', label: 'Timeline & Trace', icon: FileText },
                ].map(item => {
                  const isActive = activeTab === item.k && activeProject === 'judge';
                  const disabled = activeProject !== 'judge' && item.k !== 'timeline';
                  return (
                    <button
                      key={item.k}
                      disabled={disabled}
                      onClick={() => { if (!disabled) { setActiveTab(item.k as any); setTick(t => t+1); mainRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }); } }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-[14px] text-[13px] transition-all ${
                        isActive ? 'bg-zinc-900 text-white' : disabled ? 'opacity-40 cursor-not-allowed text-zinc-500' : 'hover:bg-white text-zinc-600'
                      }`}
                    >
                      <item.icon className="w-4 h-4" />
                      <span className="flex-1 text-left">{item.label}</span>
                      {item.count !== undefined && item.count > 0 && (
                        <span className="bg-[#DC2626] text-white text-[11px] px-2 py-0.5 rounded-full mono">{item.count}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="mt-auto">
            <div className="glass rounded-[20px] p-3 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center font-bold text-[11px]">JT</div>
              <div className="min-w-0 flex-1">
                <div className="text-[13px] font-semibold leading-none">Judge Test User</div>
                <div className="mono text-[11px] text-zinc-500 mt-1 truncate">judge@demo.day • Allowlist</div>
              </div>
              <MoreHorizontal className="w-4 h-4 text-zinc-400" />
            </div>
            <div className="mono text-[10px] text-zinc-400 mt-3 px-1">© 2025 Told You So · 60 calls left</div>
          </div>
        </aside>

        {/* MAIN COLUMN */}
        <div className="flex-1 min-w-0 flex flex-col gap-4">
          {/* TOP BAR */}
          <header
            data-safe-area-sticky-top
            style={{ top: 'var(--safe-area-inset-top)' } as any}
            className="sticky z-30 glass rounded-[24px] md:rounded-[20px] px-3 md:px-5 py-3 flex items-center gap-2 md:gap-4"
          >
            {/* mobile hamburger */}
            <button onClick={() => setMobileNavOpen(!mobileNavOpen)} className="md:hidden w-9 h-9 rounded-full bg-black text-white flex items-center justify-center">
              <Grip className="w-4 h-4" />
            </button>

            <div className="hidden lg:flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black text-white text-[12px]">
                <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                In a video call • 1:33
                <div className="flex -space-x-2 ml-2">
                  <div className="w-6 h-6 rounded-full border-2 border-black bg-[#FFE4E6] text-[10px] flex items-center justify-center font-bold">RP</div>
                  <div className="w-6 h-6 rounded-full border-2 border-black bg-[#DBEAFE] text-[10px] flex items-center justify-center font-bold">AK</div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1 p-1 rounded-full bg-[#F3F4F6] border border-zinc-200/60">
              {(['Day', 'Week', 'Month', 'Year'] as DayView[]).map(v => (
                <button
                  key={v}
                  onClick={() => setDayView(v)}
                  className={`px-3 md:px-4 py-1.5 rounded-full text-[12px] md:text-[13px] font-medium transition-all ${dayView === v ? 'bg-black text-white shadow' : 'text-zinc-500 hover:text-zinc-800'}`}
                >
                  {v}
                </button>
              ))}
            </div>

            <div className="flex-1 hidden md:flex items-center justify-center">
              <div className="relative w-full max-w-[360px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                <input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Search decisions, quotes, owners…"
                  className="w-full pl-10 pr-4 py-2 rounded-full bg-white border border-zinc-200 text-[13px] placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-black/10"
                />
                <span className="absolute right-2 top-1/2 -translate-y-1/2 mono text-[10px] px-2 py-1 rounded-full bg-zinc-900 text-white">⌘K</span>
              </div>
            </div>

            <div className="ml-auto flex items-center gap-2">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#FFF7E5] border border-amber-200 text-[11px] mono">
                <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse" />
                60 AI calls left · allowlist akash@...
              </div>
              <button onClick={() => setShowBell(!showBell)} className="relative w-9 h-9 rounded-full bg-white border border-zinc-200 flex items-center justify-center hover:shadow-sm transition">
                <Bell className="w-4 h-4" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-[#DC2626] rounded-full" />
              </button>
              <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center font-bold text-[11px] border border-white shadow-sm md:hidden">JT</div>
            </div>

            {/* bell dropdown */}
            {showBell && (
              <div className="absolute top-[56px] right-3 w-[320px] glass rounded-[20px] p-4 z-50 shadow-xl">
                <div className="flex items-center justify-between mb-3">
                  <div className="font-semibold text-[14px]">Notifications</div>
                  <button onClick={() => setShowBell(false)} className="w-6 h-6 rounded-full bg-zinc-100 flex items-center justify-center"><X className="w-3 h-3" /></button>
                </div>
                <div className="space-y-2">
                  <div className="p-3 rounded-[14px] bg-[#FEF2F2] border border-red-100 text-[12px]"><span className="font-bold text-[#DC2626]">Told you so detected</span> — blue vs green conflict needs resolution</div>
                  <div className="p-3 rounded-[14px] bg-white border text-[12px]">Notion sync: 3 tasks pushed to “Told You So Tasks”</div>
                </div>
              </div>
            )}
          </header>

          {/* MOBILE SIDEBAR */}
          {mobileNavOpen && (
            <div className="md:hidden fixed inset-0 z-40 bg-black/20 backdrop-blur-sm" onClick={() => setMobileNavOpen(false)}>
              <div className="w-[300px] h-full glass bg-[#FFFEF9]/95 p-5 flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-[10px] bg-black text-white flex items-center justify-center font-bold text-[12px]">TYS</div><span className="display font-bold">TOLD YOU SO</span></div>
                  <button onClick={() => setMobileNavOpen(false)} className="w-8 h-8 rounded-full bg-zinc-100 flex items-center justify-center"><X className="w-4 h-4" /></button>
                </div>
                <div className="space-y-2">
                  {PROJECTS.map(p => (
                    <button key={p.id} onClick={() => { setActiveProject(p.id); setMobileNavOpen(false); setActiveTab(p.id==='judge'?'capture':'timeline'); }} className={`w-full text-left px-4 py-3 rounded-full ${activeProject===p.id?'bg-black text-white':'bg-white border'}`}>{p.name}</button>
                  ))}
                </div>
                <div className="mt-auto glass rounded-[16px] p-3 flex gap-3 items-center">
                  <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center font-bold text-[10px]">JT</div>
                  <div><div className="text-[13px] font-semibold">Judge Test User</div><div className="mono text-[11px] text-zinc-500">judge@demo.day</div></div>
                </div>
              </div>
            </div>
          )}

          {/* BANNER FOR NON-JUDGE */}
          {activeProject !== 'judge' && (
            <div className="glass rounded-[18px] px-4 py-2.5 flex items-center gap-3 text-[12px] mono">
              <span className="px-2 py-1 rounded-full bg-black text-white text-[10px]">ALLOWLIST</span>
              60 AI calls left this month — you're on allowlist akash@… • Upgrade for unlimited extraction.
              <button className="ml-auto px-3 py-1 rounded-full bg-white border text-[11px]">View usage</button>
            </div>
          )}

          {/* MAIN CONTENT */}
          <main ref={mainRef} className="flex-1 min-w-0">
            {activeProject !== 'judge' ? (
              /* PROJECTS LIST SCREEN - TIMELINE */
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h1 className="display text-[28px] md:text-[36px] font-semibold tracking-tight">{activeProjectMeta.name} · Timeline</h1>
                  <button onClick={() => { setActiveProject('judge'); setActiveTab('capture'); }} className="hidden md:flex items-center gap-2 px-4 py-2 rounded-full bg-black text-white text-[13px] hover:bg-zinc-800 transition">
                    <Sparkles className="w-4 h-4" /> Open Judge Demo
                  </button>
                </div>

                <div className="grid md:grid-cols-[280px_1fr] gap-4">
                  <div className="glass rounded-[24px] p-5">
                    <div className="mono text-[11px] tracking-widest text-zinc-400 mb-4">OCTOBER</div>
                    <div className="space-y-4">
                      {[
                        { date: 'Oct 24', time: '10:00 AM', title: 'Meeting #12', sub: 'Landing Audit · Blue decision logged', active: dayView !== 'Day' },
                        { date: 'Oct 29', time: '3:00 PM', title: 'Demo Meeting', sub: 'API deadline moved? Green proposal', active: true },
                        { date: 'Oct 31', time: 'Live', title: 'Live Meeting', sub: 'Ship Decision · Not yet captured', active: false, live: true },
                      ].map(m => (
                        <div key={m.date} className={`p-4 rounded-[18px] border transition ${m.live ? 'bg-[#DC2626] text-white border-red-600' : m.active ? 'bg-black text-white border-black' : 'bg-white border-zinc-200'}`}>
                          <div className="flex items-center justify-between">
                            <span className="mono text-[11px] opacity-70">{m.date} · {m.time}</span>
                            {m.live && <span className="text-[10px] px-2 py-0.5 rounded-full bg-white text-red-600 animate-pulse mono font-bold">LIVE</span>}
                          </div>
                          <div className="font-semibold text-[14px] mt-2">{m.title}</div>
                          <div className="mono text-[11px] mt-1 opacity-70 leading-snug">{m.sub}</div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-6 p-4 rounded-[16px] bg-[#FFF8E8] border border-amber-100">
                      <div className="mono text-[11px] text-amber-700 font-semibold">INSIGHT</div>
                      <div className="text-[12px] leading-relaxed mt-1 text-zinc-700">Oct 24 decision still canonical until you confirm Oct 29 green proposal. Conflict will trigger “Told you so”.</div>
                    </div>
                  </div>

                  <div className="glass rounded-[24px] p-4 md:p-6 overflow-x-auto">
                    <div className="flex items-center justify-between mb-6">
                      <div className="display text-[20px] font-semibold">Timeline — Hours view</div>
                      <div className="mono text-[11px] text-zinc-500">{dayView} view · 08:00—19:00</div>
                    </div>

                    {/* timeline grid */}
                    <div className="min-w-[720px]">
                      <div className="grid grid-cols-[80px_repeat(12,1fr)] gap-0 text-[11px] mono text-zinc-400 mb-2">
                        <div></div>
                        {Array.from({ length: 12 }).map((_, i) => (
                          <div key={i} className="text-center">{8 + i}:00</div>
                        ))}
                      </div>
                      <div className="space-y-3">
                        {[
                          { day: 'Oct 24', blocks: [{ start: 2, span: 2, label: 'Meeting #12 10:00-11:30 · Blue decision', color: 'bg-black text-white' }] },
                          { day: 'Oct 29', blocks: [{ start: 7, span: 1, label: 'Demo 15:00 · “green for landing, pop more”', color: 'bg-zinc-800 text-white' }, { start: 9, span: 2, label: 'WhatsApp: blue still?', color: 'bg-[#FFF1E6] text-zinc-700 border border-amber-200' }] },
                          { day: 'Oct 31', blocks: [{ start: 3, span: 3, label: 'Live Meeting — Ship Decision (scheduled)', color: 'bg-white border-2 border-dashed border-zinc-300 text-zinc-500' }] },
                        ].map(row => (
                          <div key={row.day} className="grid grid-cols-[80px_repeat(12,1fr)] gap-1 items-center">
                            <div className="mono text-[12px] font-medium text-zinc-700">{row.day}</div>
                            <div className="col-span-12 grid grid-cols-12 gap-1 h-[44px] bg-[#F9FAFB] rounded-[12px] p-1">
                              {row.blocks.map((b, idx) => (
                                <div key={idx} style={{ gridColumn: `${b.start} / span ${b.span}` }} className={`rounded-[10px] px-3 flex items-center text-[11px] leading-tight ${b.color}`}>
                                  {b.label}
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="mt-8 grid md:grid-cols-3 gap-3">
                        <div className="rounded-[16px] border border-zinc-200 bg-white p-4">
                          <div className="mono text-[11px] text-zinc-400">DECISIONS LOGGED</div>
                          <div className="display text-[28px] font-semibold mt-1">12</div>
                          <div className="mono text-[11px] text-zinc-500">3 with conflicts</div>
                        </div>
                        <div className="rounded-[16px] border border-zinc-200 bg-white p-4">
                          <div className="mono text-[11px] text-zinc-400">LAST SYNC</div>
                          <div className="text-[13px] font-medium mt-1">Wispr notes · 2 min ago</div>
                          <div className="mono text-[11px] text-zinc-500">Auto-import every 5 min • ON</div>
                        </div>
                        <div className="rounded-[16px] border border-zinc-200 bg-black text-white p-4">
                          <div className="mono text-[11px] text-zinc-400">PENDING CONFIRMATION</div>
                          <div className="display text-[22px] font-semibold mt-1">{pendingCount} items need review</div>
                          <button onClick={() => { setActiveProject('judge'); setActiveTab('confirm'); }} className="mt-3 w-full py-2 rounded-full bg-white text-black text-[12px] font-medium">Open Confirmation Tray →</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : activeTab === 'capture' ? (
              /* PROJECT DETAIL - JUDGE DEMO - 4 BENTO CARDS */
              <div className="space-y-4">
                <div className="flex flex-wrap items-center gap-3">
                  <h1 className="display text-[30px] md:text-[40px] font-bold tracking-tight leading-[0.95]">Judge Demo Project<br /><span className="font-normal text-zinc-500 text-[22px] md:text-[28px]">Four ways to put info in</span></h1>
                  <button onClick={() => setModalCard('demo')} className="ml-auto md:ml-4 inline-flex items-center gap-2 px-5 py-3 rounded-full bg-black text-white text-[13px] font-medium shadow-[0_8px_24px_rgba(0,0,0,0.18)] hover:scale-[1.02] transition">
                    <Play className="w-4 h-4 fill-white" /> Play demo clip — 2:11
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 md:gap-6 auto-rows-[minmax(240px,auto)]">
                  {/* Card 1 Large: DICTATE WITH WISPR */}
                  <div className="lg:col-span-7 glass bento-card rounded-[28px] p-6 md:p-7 flex flex-col relative overflow-hidden">
                    <div className="flex items-start justify-between mb-5">
                      <div>
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-black text-white mono text-[10px] tracking-widest">01 • PRIMARY</div>
                        <h2 className="display text-[24px] md:text-[28px] font-semibold mt-3 leading-[0.95]">DICTATE WITH WISPR</h2>
                        <p className="mono text-[12px] text-zinc-500 mt-2 max-w-[44ch]">Fastest capture. We clean fillers, fix intent, keep quote fidelity. Nothing saved until you confirm.</p>
                      </div>
                      <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white border text-[11px] mono"><span className="w-2 h-2 rounded-full bg-emerald-500" /> Wispr connected</div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4 flex-1">
                      <div className="rounded-[18px] bg-[#FAFAF8] border border-zinc-200 p-4">
                        <div className="mono text-[10px] tracking-widest text-zinc-400 mb-3 flex items-center gap-2"><Mic className="w-3 h-3" /> WHAT YOU SAID</div>
                        <div className="text-[13px] leading-relaxed text-zinc-700 font-medium">
                          So <span className="text-zinc-400">um</span> let's <span className="text-zinc-400">like</span> go with <span className="strikethrough bg-[#FEF2F2]">green</span> blue for landing? <span className="text-zinc-400">you know</span> feels more <span className="text-zinc-400">uh</span> trustworthy for <span className="strikethrough">fintech</span> <span className="font-bold">fintech demo</span> page. Riya to ship docs <span className="text-zinc-400">maybe</span> before Oct 31.
                        </div>
                        <div className="mt-4 flex items-center gap-2">
                          <div className={`w-full h-[36px] rounded-full border-2 border-dashed flex items-center justify-center gap-2 text-[11px] mono transition ${isHoldingFn ? 'bg-black text-white border-black scale-[1.02]' : 'bg-white border-zinc-300 text-zinc-500'}`}>
                            {isHoldingFn ? <><span className="flex gap-1">{[0,1,2,3].map(i=><span key={i} className="w-1 bg-white rounded-full animate-[waveform_0.6s_ease_infinite]" style={{animationDelay:`${i*0.1}s`}} />)}</span> Listening… hold Fn</> : 'Hold Fn to dictate'}
                          </div>
                        </div>
                      </div>
                      <div className="rounded-[18px] bg-black text-white p-4 flex flex-col">
                        <div className="mono text-[10px] tracking-widest text-zinc-400 mb-3 flex items-center gap-2"><Sparkles className="w-3 h-3" /> WHAT WE UNDERSTOOD</div>
                        <div className="text-[14px] leading-relaxed">
                          <div className="mono text-[11px] px-2 py-1 rounded-full bg-white/10 inline-block mb-3">Decision • Landing page color</div>
                          <div className="font-medium">“Let's go with <span className="bg-white text-black px-1 rounded">blue</span> for landing — feels more trustworthy for fintech.”</div>
                          <div className="mt-4 pt-4 border-t border-white/10">
                            <div className="mono text-[11px] text-zinc-400">Action • Owner @Riya • Due Oct 31</div>
                            <div className="text-[13px] mt-1">Ship API docs + sandbox keys before demo. Send loom.</div>
                          </div>
                        </div>
                        <button
                          onMouseDown={() => setIsHoldingFn(true)}
                          onMouseUp={() => setIsHoldingFn(false)}
                          onTouchStart={() => setIsHoldingFn(true)}
                          onTouchEnd={() => setIsHoldingFn(false)}
                          className="mt-auto w-full py-3 rounded-full bg-white text-black text-[13px] font-semibold hover:bg-zinc-100 transition flex items-center justify-center gap-2"
                        >
                          <Mic className="w-4 h-4" /> Hold Fn to dictate
                        </button>
                      </div>
                    </div>

                    <button onClick={() => setModalCard('dictate')} className="absolute top-5 right-5 md:hidden w-8 h-8 rounded-full bg-white border flex items-center justify-center"><ArrowUpRight className="w-4 h-4" /></button>
                  </div>

                  {/* Card 2: LIVE MEETING */}
                  <div className="lg:col-span-5 glass bento-card rounded-[28px] p-6 flex flex-col">
                    <div className="flex items-center justify-between">
                      <div className="mono text-[10px] tracking-widest px-3 py-1 rounded-full bg-[#F3F4F6] border">02 • LIVE</div>
                      <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center"><Link2 className="w-4 h-4" /></div>
                    </div>
                    <h3 className="display text-[22px] font-semibold mt-4 leading-tight">LIVE MEETING</h3>
                    <p className="mono text-[12px] text-zinc-500 mt-1">Paste Meet / Zoom link. We listen, attribute speaker, extract after call.</p>

                    <div className="mt-5 space-y-3">
                      <div className="relative">
                        <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                        <input placeholder="https://meet.google.com/xxx-xxxx-xxx" className="w-full pl-10 pr-4 py-3 rounded-[14px] bg-white border border-zinc-200 text-[13px] focus:outline-none focus:ring-2 focus:ring-black/10" />
                      </div>
                      <button
                        onClick={() => setIsListening(!isListening)}
                        className={`w-full py-3 rounded-full text-[13px] font-semibold flex items-center justify-center gap-2 transition ${isListening ? 'bg-[#DC2626] text-white' : 'bg-black text-white hover:bg-zinc-800'}`}
                      >
                        {isListening ? <><Pause className="w-4 h-4" /> Listening… Stop</> : <><Video className="w-4 h-4" /> Listen to meeting</>}
                      </button>
                      {isListening && (
                        <div className="p-3 rounded-[12px] bg-[#FEF2F2] border border-red-200 mono text-[11px] text-red-700 flex items-center gap-2">
                          <span className="w-2 h-2 bg-red-600 rounded-full animate-pulse" /> Transcribing live · 3 speakers detected · Riya, Akash, You
                        </div>
                      )}
                      <div className="flex items-center gap-2 mono text-[11px] text-zinc-500">
                        <ShieldAlert className="w-3 h-3" /> No storage until confirm · End-to-end transcript kept locally
                      </div>
                    </div>
                    <button onClick={() => setModalCard('live')} className="mt-auto pt-4 text-[12px] mono flex items-center gap-1 hover:gap-2 transition">Open details <ChevronRight className="w-3 h-3" /></button>
                  </div>

                  {/* Card 3: IMPORT */}
                  <div className="lg:col-span-5 glass bento-card rounded-[28px] p-6 flex flex-col">
                    <div className="flex items-center justify-between">
                      <div className="mono text-[10px] tracking-widest px-3 py-1 rounded-full bg-[#F3F4F6] border">03 • IMPORT</div>
                      <Upload className="w-4 h-4 text-zinc-500" />
                    </div>
                    <h3 className="display text-[22px] font-semibold mt-4">IMPORT</h3>

                    <div className="mt-4 flex p-1 rounded-full bg-[#F3F4F6] border w-fit">
                      <button onClick={() => setImportTab('meet')} className={`px-4 py-1.5 rounded-full text-[12px] mono transition ${importTab==='meet' ? 'bg-black text-white' : 'text-zinc-500'}`}>Meet transcript</button>
                      <button onClick={() => setImportTab('chat')} className={`px-4 py-1.5 rounded-full text-[12px] mono transition ${importTab==='chat' ? 'bg-black text-white' : 'text-zinc-500'}`}>WhatsApp / Slack / Chat</button>
                    </div>

                    <div className="mt-4 rounded-[18px] border-2 border-dashed border-zinc-200 bg-white/70 p-6 text-center">
                      <div className="w-10 h-10 rounded-full bg-black text-white mx-auto flex items-center justify-center mb-3"><Upload className="w-5 h-5" /></div>
                      <div className="text-[13px] font-medium">Drop {importTab==='meet' ? 'VTT, transcript.txt' : 'WhatsApp export, Slack JSON'} here</div>
                      <div className="mono text-[11px] text-zinc-500 mt-1">or click to browse · Max 25MB · Parsed locally first</div>
                      <div className="mt-4 flex justify-center gap-2">
                        <span className="px-2 py-1 rounded-full bg-[#F3F4F6] border mono text-[10px]">meeting_12.vtt</span>
                        <span className="px-2 py-1 rounded-full bg-[#F3F4F6] border mono text-[10px]">whatsapp_fintech.txt</span>
                      </div>
                    </div>
                    <div className="mt-3 mono text-[11px] text-zinc-500 flex items-center gap-2"><FileText className="w-3 h-3" /> Last import: Oct 29 15:42 — 2 sources merged</div>
                    <button onClick={() => setModalCard('import')} className="mt-auto pt-3 text-[12px] mono flex items-center gap-1">Configure parsers <ChevronRight className="w-3 h-3" /></button>
                  </div>

                  {/* Card 4: WISPR NOTE TAKER */}
                  <div className="lg:col-span-7 glass bento-card rounded-[28px] p-6 md:p-7 flex flex-col md:flex-row gap-6">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <div className="mono text-[10px] tracking-widest px-3 py-1 rounded-full bg-[#F3F4F6] border">04 • AUTOMATION</div>
                        <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                        <span className="mono text-[11px] text-emerald-700">Live</span>
                      </div>
                      <h3 className="display text-[22px] font-semibold mt-4">WISPR NOTE TAKER</h3>
                      <p className="mono text-[12px] text-zinc-500 mt-1 max-w-[36ch]">Auto-imports your Wispr Flow notes every 5 minutes. Keeps a local ledger, never pushes without confirm.</p>

                      <div className="mt-6 space-y-4">
                        <div className="flex items-center justify-between p-3 rounded-[14px] bg-white border">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center"><Clock className="w-4 h-4" /></div>
                            <div>
                              <div className="text-[13px] font-medium">Auto-import every 5 min</div>
                              <div className="mono text-[11px] text-zinc-500">Last sync: 2 min ago · 3 new notes</div>
                            </div>
                          </div>
                          <button onClick={() => setAutoImport(!autoImport)} className={`w-12 h-7 rounded-full p-1 transition ${autoImport ? 'bg-black' : 'bg-zinc-300'}`}>
                            <div className={`w-5 h-5 rounded-full bg-white transition ${autoImport ? 'translate-x-5' : ''}`} />
                          </button>
                        </div>

                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { label: 'Today', val: '12 notes' },
                            { label: 'Extracted', val: '7 decisions' },
                            { label: 'Pending', val: '3 to confirm' },
                          ].map(s => (
                            <div key={s.label} className="rounded-[12px] bg-[#FAFAF8] border p-3">
                              <div className="mono text-[10px] text-zinc-400">{s.label.toUpperCase()}</div>
                              <div className="text-[13px] font-semibold mt-1">{s.val}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="md:w-[240px] rounded-[18px] bg-black text-white p-4 flex flex-col">
                      <div className="mono text-[10px] tracking-widest text-zinc-400">LATEST WISPR NOTE</div>
                      <div className="mt-3 text-[12px] leading-relaxed mono">
                        <div className="text-zinc-400">09:14 · flow.md</div>
                        <div className="mt-2">“Actually API deadline — Riya said Oct 31 is hard stop, not flexible. Keep blue? Need to check WhatsApp.”</div>
                      </div>
                      <div className="mt-auto pt-4">
                        <div className="mono text-[10px] text-zinc-500 mb-2">LEDGER STATUS</div>
                        <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden"><div className="h-full w-[72%] bg-white rounded-full" /></div>
                        <div className="mono text-[10px] text-zinc-400 mt-2">72% ready for confirm</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : activeTab === 'confirm' ? (
              /* CONFIRMATION TRAY SCREEN */
              <div className="space-y-4 max-w-[1120px]">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-black text-white mono text-[11px] tracking-widest"><Inbox className="w-3 h-3" /> CONFIRMATION TRAY · NOTHING SAVED UNTIL CONFIRM</div>
                    <h1 className="display text-[32px] md:text-[42px] font-semibold leading-[0.9] mt-3">Review what we heard.<br />Decide what sticks.</h1>
                    <p className="mono text-[13px] text-zinc-600 mt-3 max-w-[60ch]">Every item is a quote with source. Edit, accept, or drop. Objections are flagged automatically. Ledger only writes after you confirm.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button disabled={busy} onClick={handleAcceptAll} className="px-5 py-2.5 rounded-full bg-black text-white text-[13px] font-medium disabled:opacity-50 hover:bg-zinc-800 transition flex items-center gap-2">
                      <Check className="w-4 h-4" /> Accept all valid ({pendingCount})
                    </button>
                    <div className="mono text-[11px] text-zinc-500 px-3">Saved: {records.length} · {result ? `${result.saved} saved, ${result.remaining} remaining` : 'local ledger'}</div>
                  </div>
                </div>

                {result?.error && (
                  <div className="p-4 rounded-[16px] bg-[#FEF2F2] border border-red-200 text-[12px] mono text-red-700">
                    Save error: {result.error} — {result.remaining} items remain. Confirmed saves preserved.
                  </div>
                )}

                <div className="grid gap-4">
                  {confirmItems.map(item => (
                    <div key={item.id} className={`glass rounded-[24px] p-5 md:p-6 bento-card border-l-[6px] ${item.kind==='objection_red' ? 'border-l-[#DC2626]' : item.kind==='conflict_yellow' ? 'border-l-amber-400' : 'border-l-black'}`}>
                      <div className="flex flex-wrap items-start justify-between gap-4">
                        <div className="flex-1 min-w-[280px]">
                          <div className="flex items-center gap-2 mb-3">
                            {item.kind==='decision' && <span className="px-2.5 py-1 rounded-full bg-black text-white mono text-[10px] tracking-widest">DECISION</span>}
                            {item.kind==='action' && <span className="px-2.5 py-1 rounded-full bg-[#EDE9FE] text-[#6D28D9] mono text-[10px] tracking-widest">ACTION • {item.owner} DUE {item.due}</span>}
                            {item.kind==='objection_red' && <span className="px-2.5 py-1 rounded-full bg-[#DC2626] text-white mono text-[10px] tracking-widest flex items-center gap-1"><ShieldAlert className="w-3 h-3" /> TOLD YOU SO</span>}
                            {item.kind==='conflict_yellow' && <span className="px-2.5 py-1 rounded-full bg-amber-400 text-black mono text-[10px] tracking-widest flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> SOURCES DON'T MATCH</span>}
                            <span className="mono text-[11px] text-zinc-500">{item.source}</span>
                          </div>

                          {editingId === item.id ? (
                            <div className="space-y-3">
                              <textarea value={editQuote} onChange={e=>setEditQuote(e.target.value)} className="w-full p-3 rounded-[14px] border bg-white text-[14px] leading-relaxed" rows={3} />
                              <div className="flex gap-2">
                                <button onClick={()=>{ setConfirmItems(prev=>prev.map(p=>p.id===item.id?{...p, quote:editQuote}:p)); setEditingId(null); }} className="px-4 py-2 rounded-full bg-black text-white text-[12px]">Save edit</button>
                                <button onClick={()=>setEditingId(null)} className="px-4 py-2 rounded-full bg-white border text-[12px]">Cancel</button>
                              </div>
                            </div>
                          ) : (
                            <div className="display text-[18px] md:text-[20px] leading-[1.25] font-medium">“{item.quote}”</div>
                          )}

                          {item.kind==='objection_red' && (
                            <div className="mt-4 grid md:grid-cols-2 gap-3">
                              <div className="rounded-[14px] bg-[#FAFAF8] border p-4">
                                <div className="mono text-[10px] tracking-widest text-zinc-400">OLD DECISION</div>
                                <div className="text-[13px] mt-2 leading-relaxed">{item.oldDecision}</div>
                                <div className="mono text-[11px] text-zinc-500 mt-2">{item.oldSource}</div>
                              </div>
                              <div className="rounded-[14px] bg-[#FEF2F2] border border-red-200 p-4">
                                <div className="mono text-[10px] tracking-widest text-[#DC2626]">NEW QUOTE</div>
                                <div className="text-[13px] mt-2 leading-relaxed">“let’s actually try green for landing, pop more” — Oct 29 Demo Meeting, Riya Patel, 15:14</div>
                              </div>
                            </div>
                          )}

                          {item.kind==='conflict_yellow' && (
                            <div className="mt-4 rounded-[14px] bg-amber-50 border border-amber-200 p-4 mono text-[12px] leading-relaxed">
                              <div className="font-semibold">WhatsApp (yesterday 9:14pm) · Riya:</div>
                              <div>“are we still blue? client liked blue yesterday”</div>
                              <div className="mt-2 font-semibold">Meeting transcript (today 3:14pm) · You:</div>
                              <div>“Let’s go with blue for landing — feels more trustworthy” vs earlier green proposal</div>
                            </div>
                          )}
                        </div>

                        <div className="flex md:flex-col gap-2 shrink-0">
                          <button onClick={()=>{ setEditingId(item.id); setEditQuote(item.quote); }} className="w-9 h-9 md:w-auto md:px-4 md:py-2 rounded-full bg-white border flex items-center justify-center gap-2 text-[12px] hover:shadow-sm"><Edit3 className="w-4 h-4" /><span className="hidden md:inline">Edit</span></button>
                          <button disabled={busy || item.status!=='pending'} onClick={()=>handleAcceptItem(item)} className={`w-9 h-9 md:w-auto md:px-4 md:py-2 rounded-full flex items-center justify-center gap-2 text-[12px] font-medium transition ${item.status==='accepted' ? 'bg-emerald-600 text-white' : 'bg-black text-white hover:bg-zinc-800 disabled:opacity-40'}`}><Check className="w-4 h-4" /><span className="hidden md:inline">{item.status==='accepted' ? 'Accepted' : 'Accept'}</span></button>
                          <button onClick={()=>setConfirmItems(prev=>prev.map(p=>p.id===item.id?{...p, status:'dropped' as const}:p))} className="w-9 h-9 md:w-auto md:px-4 md:py-2 rounded-full bg-white border flex items-center justify-center gap-2 text-[12px] hover:bg-zinc-50"><X className="w-4 h-4" /><span className="hidden md:inline">Drop</span></button>
                        </div>
                      </div>

                      {item.kind==='objection_red' && item.status==='pending' && (
                        <div className="mt-5 flex flex-wrap gap-2">
                          <button onClick={()=>handleAcceptItem({...item, resolution:'new_wins'})} className="px-4 py-2 rounded-full bg-[#DC2626] text-white text-[12px] font-medium">New wins — green replaces blue</button>
                          <button onClick={()=>handleAcceptItem({...item, resolution:'keep_old'})} className="px-4 py-2 rounded-full bg-black text-white text-[12px] font-medium">Keep old — blue stays canonical</button>
                          <button className="px-4 py-2 rounded-full bg-white border text-[12px]">Not a conflict — both valid</button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <div className="glass rounded-[20px] p-4 flex items-center gap-3 mono text-[11px]">
                  <Database className="w-4 h-4" />
                  Ledger writes only after confirm. {records.length} records persisted via trusted API. API 60 calls left this month.
                </div>
              </div>
            ) : activeTab === 'act' ? (
              /* ACT - NOTION + OUTBOX */
              <div className="space-y-4 max-w-[1200px]">
                <div className="flex items-center justify-between">
                  <h1 className="display text-[32px] font-semibold">Act · Notion + Outbox</h1>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 mono text-[11px] text-emerald-700 flex items-center gap-1"><span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> Notion connected</span>
                    <span className="px-3 py-1 rounded-full bg-white border mono text-[11px]">Outbox: 7 scheduled</span>
                  </div>
                </div>

                <div className="grid lg:grid-cols-[1.4fr_0.9fr] gap-4">
                  <div className="glass rounded-[24px] p-6">
                    <div className="flex items-center justify-between mb-5">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-[12px] bg-black text-white flex items-center justify-center font-bold">N</div>
                        <div>
                          <div className="font-semibold text-[14px]">Told You So Tasks · Notion database</div>
                          <div className="mono text-[11px] text-zinc-500">Owner / Due / Status / Project / Quote columns</div>
                        </div>
                      </div>
                      <button className="px-3 py-1.5 rounded-full bg-white border text-[11px] mono flex items-center gap-1"><ExternalLink className="w-3 h-3" /> Open in Notion</button>
                    </div>

                    <div className="overflow-x-auto rounded-[16px] border bg-white">
                      <div className="min-w-[680px]">
                        <div className="grid grid-cols-[1.2fr_0.6fr_0.6fr_0.6fr_0.7fr_1.5fr] gap-0 mono text-[11px] tracking-widest text-zinc-400 border-b bg-[#FAFAF8] p-3">
                          <div>NAME</div><div>OWNER</div><div>DUE</div><div>STATUS</div><div>PROJECT</div><div>QUOTE</div>
                        </div>
                        {[
                          { name: 'Ship API docs + sandbox', owner: '@Riya', due: 'Oct 31', status: 'In progress', project: 'Judge Demo', quote: '“Ship API docs before demo” — Oct 29' },
                          { name: 'Landing: finalize blue', owner: '@You', due: 'Oct 30', status: 'Needs decision', project: 'Client Website #3', quote: '“Let’s go with blue for landing”' },
                          { name: 'Told you so: blue→green?', owner: '@Riya', due: 'Oct 31', status: 'Conflict', project: 'Judge Demo', quote: 'Old Oct 24 vs New Oct 29 green proposal' },
                        ].map((r,i)=>(
                          <div key={i} className="grid grid-cols-[1.2fr_0.6fr_0.6fr_0.6fr_0.7fr_1.5fr] gap-0 p-3 text-[12px] border-b last:border-b-0 hover:bg-[#FFFEF9] transition">
                            <div className="font-medium pr-2">{r.name}</div>
                            <div className="mono text-[11px]">{r.owner}</div>
                            <div className="mono text-[11px]">{r.due}</div>
                            <div><span className={`px-2 py-1 rounded-full text-[10px] mono ${r.status==='Conflict' ? 'bg-[#FEF2F2] text-[#DC2626]' : r.status==='Needs decision' ? 'bg-amber-100 text-amber-800' : 'bg-zinc-900 text-white'}`}>{r.status}</span></div>
                            <div className="mono text-[11px]">{r.project}</div>
                            <div className="text-[11px] text-zinc-600 truncate">{r.quote}</div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="mt-5 grid md:grid-cols-2 gap-3">
                      <div className="rounded-[16px] border bg-white p-4">
                        <div className="mono text-[11px] text-zinc-400">EMAIL REMINDERS</div>
                        <div className="mt-2 space-y-2">
                          <div className="flex items-center justify-between text-[12px]"><span>2 min demo (judge mode)</span><span className="px-2 py-1 rounded-full bg-black text-white mono text-[10px]">ON</span></div>
                          <div className="flex items-center justify-between text-[12px]"><span>24h default</span><span className="px-2 py-1 rounded-full bg-zinc-100 mono text-[10px]">OFF in demo</span></div>
                        </div>
                      </div>
                      <div className="rounded-[16px] border bg-[#FFFEF9] p-4">
                        <div className="mono text-[11px] text-zinc-400">AUTOMATION</div>
                        <div className="text-[12px] mt-2 leading-relaxed">When decision accepted → create Notion row → schedule reminder (2 min demo, 24h prod) → log to outbox.</div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="glass rounded-[24px] p-6">
                      <div className="flex items-center gap-2 mb-4">
                        <Mail className="w-4 h-4" />
                        <h3 className="font-semibold text-[14px]">Outbox · Reminders / Digests log</h3>
                      </div>
                      <div className="space-y-2">
                        {[
                          { type: 'Reminder', to: 'Riya Patel', subject: 'API docs due Oct 31 — hard stop', when: 'Scheduled in 2 min', status: 'Queued' },
                          { type: 'Digest', to: 'You', subject: 'Daily: 3 decisions pending, 1 conflict', when: 'Sent 09:00 today', status: 'Sent' },
                          { type: 'Told you so', to: 'You + Riya', subject: 'Conflict: blue → green landing', when: 'Scheduled now', status: 'Ready' },
                          { type: 'Reminder', to: 'Akash', subject: 'Judge Demo Project: confirm tray has 3 items', when: 'Sent yesterday 18:32', status: 'Delivered' },
                        ].map((m,i)=>(
                          <div key={i} className="p-3 rounded-[14px] bg-white border flex gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${m.status==='Queued' ? 'bg-amber-100 text-amber-700' : 'bg-zinc-900 text-white'}`}><Mail className="w-4 h-4" /></div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <span className="mono text-[10px] px-2 py-0.5 rounded-full bg-[#F3F4F6] border">{m.type}</span>
                                <span className="mono text-[11px] text-zinc-500 truncate">{m.when} · {m.status}</span>
                              </div>
                              <div className="text-[12px] font-medium mt-1 truncate">To: {m.to} — {m.subject}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="glass rounded-[24px] p-5 bg-black text-white">
                      <div className="mono text-[11px] text-zinc-400">SHIPPING CHECKLIST</div>
                      <div className="mt-3 space-y-2 text-[12px]">
                        <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Notion DB created “Told You So Tasks”</div>
                        <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Outbox logging working</div>
                        <div className="flex items-center gap-2"><div className="w-4 h-4 rounded-full border border-white/30 flex items-center justify-center"><div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /></div> Email demo: 2 min delay (prod 24h)</div>
                      </div>
                      <button className="mt-4 w-full py-2.5 rounded-full bg-white text-black text-[12px] font-medium">Configure reminders →</button>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* LOOK BACK - TIMELINE + AGENT TRACE */
              <div className="space-y-4 max-w-[1120px]">
                <h1 className="display text-[32px] font-semibold">Look Back · Timeline + Agent Trace</h1>
                <div className="grid lg:grid-cols-[1.2fr_0.8fr] gap-4">
                  <div className="glass rounded-[24px] p-6">
                    <div className="flex items-center justify-between mb-6">
                      <div className="font-semibold">Ordered project timeline — which decisions replaced which</div>
                      <div className="mono text-[11px] px-2 py-1 rounded-full bg-black text-white">{dayView} view</div>
                    </div>

                    <div className="relative pl-8">
                      <div className="absolute left-[11px] top-0 bottom-0 w-[2px] bg-gradient-to-b from-black via-zinc-300 to-transparent" />
                      {[
                        { date: 'Oct 24 · 10:32 AM', title: 'Decision #12: Landing page — BLUE', desc: '“We decided blue for landing — brand trust.” Meeting #12, you + Riya. Canonical until conflict.', tag: 'CANONICAL', color: 'bg-black text-white' },
                        { date: 'Oct 29 · 3:14 PM', title: 'Proposal: green for landing, pop more', desc: 'Demo Meeting. Riya: “let’s actually try green for landing, pop more”. Flagged as potential override.', tag: 'PROPOSAL', color: 'bg-zinc-100 text-zinc-700 border' },
                        { date: 'Oct 29 · 9:14 PM', title: 'WhatsApp: “are we still blue?”', desc: 'Riya in WhatsApp export. Cross-source conflict detected with meeting transcript.', tag: 'CONFLICT', color: 'bg-amber-400 text-black' },
                        { date: 'Oct 31 · Scheduled', title: 'Live Meeting — Ship Decision pending', desc: 'API deadline hard stop per Riya. Decision must be finalized before demo.', tag: 'PENDING', color: 'bg-white border border-dashed' },
                      ].map((ev, i) => (
                        <div key={i} className="relative pb-8 last:pb-0">
                          <div className={`absolute left-[-28px] top-1 w-6 h-6 rounded-full border-4 border-[#FFFEF9] flex items-center justify-center ${i===0 ? 'bg-black' : i===1 ? 'bg-zinc-400' : i===2 ? 'bg-amber-400' : 'bg-white border-2'}`}><div className="w-1.5 h-1.5 bg-white rounded-full" /></div>
                          <div className="flex items-center gap-2 mb-2">
                            <span className="mono text-[11px] text-zinc-500">{ev.date}</span>
                            <span className={`mono text-[10px] px-2 py-0.5 rounded-full ${ev.color}`}>{ev.tag}</span>
                          </div>
                          <div className="font-semibold text-[14px]">{ev.title}</div>
                          <div className="mono text-[12px] text-zinc-600 mt-1 leading-relaxed max-w-[60ch]">{ev.desc}</div>
                          {i===1 && (
                            <div className="mt-3 p-3 rounded-[12px] bg-[#FEF2F2] border border-red-200 text-[11px] mono flex items-center gap-2 text-red-700">
                              <ShieldAlert className="w-4 h-4" /> Told you so: This would replace Oct 24 blue decision. Needs explicit confirm: New wins / Keep old / Not a conflict.
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="glass rounded-[24px] p-6 bg-black text-white">
                      <div className="flex items-center gap-2 mb-4">
                        <div className="w-7 h-7 rounded-full bg-white text-black flex items-center justify-center"><Zap className="w-4 h-4" /></div>
                        <h3 className="font-semibold">Agent Trace — AI steps</h3>
                      </div>
                      <div className="space-y-3">
                        {[
                          { step: '01', name: 'Transcribe', detail: 'Wispr + Meet VTT + WhatsApp export → unified transcript, 3 speakers diarized', time: '12.4s' },
                          { step: '02', name: 'Attribute', detail: 'Speaker ID: You (60%), Riya Patel (35%), Akash (5%). Source timestamps preserved.', time: '2.1s' },
                          { step: '03', name: 'Extract', detail: 'Decision vs Action classifier. Quote fidelity >95%. Owner @Riya, Due Oct 31 extracted.', time: '4.8s' },
                          { step: '04', name: 'Conflict check', detail: 'Vector search vs ledger. Found Oct 24 blue decision. Flagged: Told you so + Sources mismatch.', time: '3.2s' },
                        ].map(s => (
                          <div key={s.step} className="p-3 rounded-[14px] bg-white/10 border border-white/10 flex gap-3">
                            <div className="mono text-[11px] px-2 py-1 rounded-full bg-white text-black h-fit">{s.step}</div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <span className="font-medium text-[13px]">{s.name}</span>
                                <span className="mono text-[10px] text-zinc-400">{s.time}</span>
                              </div>
                              <div className="mono text-[11px] text-zinc-300 mt-1 leading-relaxed">{s.detail}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-4 p-3 rounded-[12px] bg-white/5 border border-white/10 mono text-[11px] text-zinc-300">
                        <div className="flex items-center gap-2 text-white"><Database className="w-3 h-3" /> Ledger state: 12 decisions, 3 conflicts, 7 actions. Nothing written until confirm.</div>
                      </div>
                    </div>

                    <div className="glass rounded-[24px] p-5">
                      <div className="mono text-[11px] tracking-widest text-zinc-400 mb-3">QUOTE FIDELITY CHECK</div>
                      <div className="space-y-3 text-[12px]">
                        <div className="flex justify-between"><span className="text-zinc-500">Fillers removed</span><span className="mono">um, like, uh, you know — strikethrough in UI</span></div>
                        <div className="flex justify-between"><span className="text-zinc-500">Corrections</span><span className="mono">green → blue (kept both with conflict)</span></div>
                        <div className="flex justify-between"><span className="text-zinc-500">Owner inference</span><span className="mono">@Riya from “Riya to ship”</span></div>
                        <div className="flex justify-between"><span className="text-zinc-500">Due inference</span><span className="mono">Oct 31 hard stop — from 09:14 Wispr note</span></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </main>

          {/* footer mono */}
          <div className="mt-2 mono text-[10px] text-zinc-400 flex items-center justify-between px-2">
            <span>Built for judges · 4 capture methods · Confirm before save · Notion + Outbox · Timeline + Trace</span>
            <span className="hidden md:inline">Fraunces + IBM Plex Mono · Paper #FFFEF9 · Ink #111827 · Stamp #DC2626</span>
          </div>
        </div>
      </div>

      {/* MODALS */}
      {modalCard && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-3 md:p-6 bg-black/30 backdrop-blur-[12px]" onClick={() => setModalCard(null)}>
          <div onClick={e => e.stopPropagation()} className="w-full max-w-[720px] glass rounded-[28px] p-6 md:p-8 shadow-2xl max-h-[90vh] overflow-auto no-scrollbar">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center">
                  {modalCard==='dictate' ? <Mic className="w-5 h-5" /> : modalCard==='live' ? <Video className="w-5 h-5" /> : modalCard==='import' ? <Upload className="w-5 h-5" /> : modalCard==='wispr' ? <Clock className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </div>
                <div>
                  <div className="font-semibold text-[16px]">{modalCard==='dictate' ? 'Dictate with Wispr — deep dive' : modalCard==='live' ? 'Live Meeting — how it works' : modalCard==='import' ? 'Import — parsers' : modalCard==='wispr' ? 'Wispr Note Taker — automation' : 'Demo clip — 2:11'}</div>
                  <div className="mono text-[11px] text-zinc-500">Judge Demo Project · Nothing saved until confirm</div>
                </div>
              </div>
              <button onClick={()=>setModalCard(null)} className="w-9 h-9 rounded-full bg-white border flex items-center justify-center"><X className="w-4 h-4" /></button>
            </div>

            {modalCard==='demo' ? (
              <div className="space-y-4">
                <div className="aspect-video rounded-[18px] bg-black flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-zinc-800 to-black" />
                  <div className="relative z-10 text-center text-white p-6">
                    <div className="w-16 h-16 rounded-full bg-white text-black mx-auto flex items-center justify-center mb-4"><Play className="w-7 h-7 fill-black ml-0.5" /></div>
                    <div className="display text-[20px] font-semibold">Told You So — 2 min judge demo</div>
                    <div className="mono text-[12px] text-zinc-400 mt-2">Dictate → Import WhatsApp + Meet → Confirm tray with Told You So objection → Notion + Outbox → Timeline</div>
                  </div>
                </div>
                <div className="grid md:grid-cols-3 gap-3 mono text-[11px]">
                  <div className="p-3 rounded-[12px] bg-[#FAFAF8] border">0:00-0:31 Dictate blue landing + Riya action</div>
                  <div className="p-3 rounded-[12px] bg-[#FEF2F2] border border-red-100">0:31-1:14 Conflict detection: Oct 24 vs Oct 29</div>
                  <div className="p-3 rounded-[12px] bg-[#F3F4F6] border">1:14-2:11 Notion push + 2 min reminder + timeline</div>
                </div>
              </div>
            ) : (
              <div className="space-y-4 text-[13px] leading-relaxed">
                <p>Real copy from hackathon: decisions about landing page color (blue for trust vs green for pop), API deadline Oct 31 hard stop per Riya, Wispr Flow notes auto-import every 5 min.</p>
                <div className="p-4 rounded-[16px] bg-[#FFFEF9] border mono text-[12px]">
                  <div className="font-semibold">Implementation notes</div>
                  <ul className="list-disc ml-4 mt-2 space-y-1 text-zinc-600">
                    <li>Transcribe → Attribute → Extract → Conflict check (agent trace visible in Timeline & Trace)</li>
                    <li>Quote fidelity: greyed fillers (um, like), strikethrough corrections, owner @Riya, due Oct 31 inference</li>
                    <li>Ledger writes only after Confirm tray Accept. Uses trusted records API (records.list / records.create)</li>
                    <li>Notion: “Told You So Tasks” DB with Owner/Due/Status/Project/Quote</li>
                    <li>Outbox: 2 min demo reminder, 24h prod default — logged with schedule/sent/status</li>
                  </ul>
                </div>
                <div className="flex gap-2">
                  <button onClick={()=>setModalCard(null)} className="px-5 py-2.5 rounded-full bg-black text-white text-[13px]">Close</button>
                  <button onClick={()=>{ setModalCard(null); setActiveTab('confirm'); }} className="px-5 py-2.5 rounded-full bg-white border text-[13px]">Go to Confirm Tray →</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* floating quick action */}
      <button
        onClick={() => setActiveTab('confirm')}
        className="fixed bottom-5 right-5 md:bottom-6 md:right-6 z-30 px-5 py-3 rounded-full bg-black text-white shadow-[0_12px_32px_rgba(0,0,0,0.24)] flex items-center gap-2 text-[13px] font-medium hover:scale-[1.02] transition"
      >
        <Inbox className="w-4 h-4" /> Confirm {pendingCount} pending
        <span className="w-5 h-5 rounded-full bg-[#DC2626] text-white text-[11px] flex items-center justify-center mono">{pendingCount}</span>
      </button>
    </div>
  );
}
